
public class CustomerReview {

	private String reviewMesage;

	public String getReviewMesage() {
		return reviewMesage;
	}

	public void setReviewMesage(String reviewMesage) {
		this.reviewMesage = reviewMesage;
	}
}
