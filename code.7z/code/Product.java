import java.util.List;

public class Product
{
  private List<CustomerReview> CustomerReviewList ;

public List<CustomerReview> getCustomerReviewList() {
	return CustomerReviewList;
}

public void setCustomerReviewList(List<CustomerReview> customerReviewList) {
	CustomerReviewList = customerReviewList;
}



}
