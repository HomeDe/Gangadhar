import java.util.List;

@FleibleSearchQuery
public class CustomerReviewDAOImpl implements CustomerReviewDAO {

	
	 private List<CustomerReview> CustomerReviewList;
	public List<CustomerReview> getCustomerReview() {
		
		String query="Select CustomerReview.customerid form Product as p left join" +
				"customerReview c on p.id=c.id";
		
		finalSearchResult<CustomerReview> searchResult=flexibleSearchService.search(query);
		
		CustomerReviewList =searchResult.getResult();
	}

}

