import java.util.List;


public class CustomerReviewFacde {

	 private List<CustomerReview> CustomerReviewList;
	public List<CustomerReview> getCustomerReview() {
		// TODO Auto-generated method stub
		
		CustomerReviewDAO customerReviewDAO=new CustomerReviewDAO();
		
		return customerReviewDAO.getCustomerReview;
	}

}
