import java.util.List;


public interface CustomerReviewDAO {
	
	List<CustomerReview> getCustomerReview();

}
